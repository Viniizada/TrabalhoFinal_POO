class Amigo extends Pessoa {
    public Amigo(String nome, String email) {
        super(nome, email);
    }
}